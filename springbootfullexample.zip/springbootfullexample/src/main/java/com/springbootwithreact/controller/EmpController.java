package com.springbootwithreact.controller;

import java.util.List;

import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootwithreact.model.Employee;
import com.springbootwithreact.service.EmpService;

@RestController
@RequestMapping("/emp")
public class EmpController {
	
	@Autowired
	EmpService empService;
	


	@PostMapping("/saveEmp")
	public void saveEmp(@RequestBody Employee emp)
	{
		empService.saveEmp(emp);
	}
	
	
	@GetMapping("/getEmp")
	public List<Employee> getEmp()
	{
		return empService.getEmp();
		
	}
	
	@PutMapping("/updateEmp/{id}")
	public void updateEmp(@RequestBody Employee emp,@PathVariable Integer id)
	{
		empService.updateEmp(emp,id);
	}
	
	@DeleteMapping("/deleteEmp/{id}")
	public void deleteEmp(@PathVariable Integer id)
	{
		empService.deleteEmp(id);	
	}
}
