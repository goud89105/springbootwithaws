package com.springbootwithreact.service;

import java.util.List;

import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.springbootwithreact.dao.EmpRepository;
import com.springbootwithreact.model.Employee;

@Service
public class EmpService {

	
	@Autowired
	EmpRepository empRepository;
	
	
	public void saveEmp(Employee emp)
	{
		empRepository.save(emp);
	}
	
	
	public List<Employee> getEmp()
	{
		return empRepository.findAll();
		
	}
	
	
	public void updateEmp(Employee emp,Integer id)
	{
		 Employee employee=empRepository.findById(id).orElseThrow();
		 employee.setEmpid(emp.getEmpid());
		 employee.setEmpName(emp.getEmpName());
		 employee.setEmpAddress(emp.getEmpAddress());
		 empRepository.save(employee);
	}
	public void deleteEmp(Integer id)
	{
		empRepository.deleteById(id);
	}
}
