package com.springbootwithreact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfullexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
